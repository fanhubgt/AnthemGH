package com.processing.anthemgh;

import android.app.Activity;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.speech.tts.TextToSpeech;

import java.io.IOException;
import java.util.Locale;

import processing.core.PApplet;
import processing.core.PImage;

public class AnthemApplet extends PApplet{
    Context context;
    Activity act;
    AssetFileDescriptor afd;
    TextToSpeech t1;

    int i =4, j=0, m=0, b=1, eye=175, s=1;
    String bub="20200419_", scimg="sc", eyestr="20200420_" ;
    float wid=40, hei=140;
    float xd=width/5+30, yd=height/4+45;
    int c1= color(55, 44, 27, 155);
    int c2=color(45, 123, 189, 206);
    int c3=color(16, 89, 50, 167);
    int c4=color(19, 69, 170, 188);
    int c5=color(12, 12, 80, 225);
    int c6=color(113,3,120, 100);
    int c7=color(86,225, 137, 155);
    int c8=color(233, 70,120, 120);

    float trans=10;
    float flashRand=0;
    float w[]={wid, wid, wid+30, wid-48, wid},
            h[]={hei, hei, hei, hei, hei},
            x[]={xd-30, xd+80, xd+130, xd+225, xd+240},
            y[]={yd, yd, yd, yd, yd};
    int higc, infc, selc, c[]={c1, c2, c3, c4, c5, c6, c7, c8};
    int UpDown=0, msg=0;
    boolean pledge=false, orientState=false, isporta=false, start=false, locked=false, info=false, pause=false, showKB=false, clear=false, flash=false, menu=true, fixed=false, unanimate=false, animate=false, animateUpDown=false;

    String menuStr="\n\nMenu  :M key\n=============\nFlash     :"+
            " F(f) key\nAnimate Recta   :O(o) key\nAnimate Right"+"    :U(u) key\nAnimate UpDown   "+
            ":I(i) key\nAnimate Up    :E(e) key\nAnimate UpMiddle   :A(a) key\nSound   :Stop(s|S) Play|Pause(p|P) Key\nClose/Quit     :q|c|C Key\nDeveloped by:Dr. Frank Appiah(SGTBiz GH).\nDonate:Voda-M Money +233204702873";
    String message[] ={"Reciting  National Anthem, You Anthemist of Ghana. ", "God bless our homeland Ghana", "And make our nation great and strong .",
            "Bold to defend forever.", "The course of freedom and of right .",
            "Fill our heart with true humility.", "Make us cherish, fearless, honesty", "And help us to resist oppressors rule", "With all our will and might for ever more",
            "That ends the national anthem. ", "Now is the pledge. ", " I promise on my honor to be faithful and loyal. ", " To Ghana my motherland. ",
            "I pledge myself to the service of Ghana with all", "My strength and with all my heart"
            , "I promise to hold in high esteem our heritage", "Won for us through the blood and toil of our fathers. ",
            "And I pledge myself in all things to uphold and.\n Defend the good name of Ghana, so help me God.", "Jot any ideas down and get in touch with me at appiahnsiahfrank@gmail.com", "Will definitely respond to your emails",
            "Is your time well spent", "Reciting and learning through the  process. " };

    String sb[] ={"anthemins.m4a", "anthem.ogg", "cyber1.mp3", "sb1.3gpp", "sb2.3gpp", "sb3.3gpp"};
    PImage podimg, pad, comic, splash, bubble, pscimg, eyeimg;
    MediaPlayer mp;
    int be=0, flag=0;
    String flags[] ={"pl1.png", "pl2.jpeg", "pl3.jpeg", "pl4.jpg", "pl5.jpeg", "pl6.png", "pl7.jpeg", "pl8.jpeg", "pl9.jpeg", "pl10.jpeg", "pl11.jpeg", "pl12.jpeg", "pl13.jpeg", "pl14.jpeg", "pl15.jpeg", "pl16.jpeg", "pl17.jpeg", "pl18.jpeg", "pl19.png", "pl20.jpeg", "pl21.jpeg", "pl22.jpeg" };
    CircleButton orientBtn, landBtn, portBtn, startBtn;
    RectButton spkBtn, quitBtn, insBtn, flashBtn, soundBtn, pauseBtn, backBtn, padBtn, fixBtn, animBtn, updoAnimBtn, unanimBtn;
    PImage flagImage;

    AnthemApplet(AnthemActivity fullscreenActivity){
        this.act=fullscreenActivity;
    }


    public void settings(){
        fullScreen(P3D) ;
    }

   public  void setup()
    {
        //size(450, 480);
        //size(750,780);

           textSize(40);
           splash=loadImage("spl4.jpg");
        bubble=loadImage("spl3.jpg");
        pscimg=loadImage("spl2.jpg");
        eyeimg=loadImage("spl1.jpg") ;
        pad=loadImage("pad.jpg") ;
        podimg=loadImage("nam.jpg" ) ;
        flagImage=loadImage(flags[flag]) ;
        //comov=new Gif(this,"comica.gif") ;
        //comov.loop();
        loadaudio("anthem.ogg") ;
        blendMode(BLEND) ;

        // mp.start();
        t1=new TextToSpeech(context, new TextToSpeech.OnInitListener()
        {
            @Override public void onInit(int status)
            {
                if (status != TextToSpeech.ERROR)
                {
                    t1.setLanguage(Locale.UK);
                }
            }
        }
        );
        for (int k=0; k<i; k++) {
            background(c[k]);
            rect(x[k], y[k], w[k], h[k], 8);
        }
        createButtons();

        // flush();
        t1.speak("Welcome you Anthemist.  This is an anthem and pledge recital app. ", TextToSpeech.QUEUE_FLUSH, null) ;

        // image(comic, 0, height/2, width/5,height/5);
        frameRate(3);
    }

    void loadaudio(String file) {
        act = this.getActivity();
        context = act.getApplicationContext();
        try {
            mp = new MediaPlayer();
            afd = context.getAssets().openFd(file);//which is in the data folder
            //println("Successfully loaded audio file");
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            mp.setVolume(0.7f, 0.6f);
            mp.setLooping(true);
            mp.prepare() ;
        }
        catch(IOException e)
        {// println("file did not load");
        }
    }
    void createButtons() {
        higc=color(128,112, 96, 199) ;
        selc=color(162, 69, 104) ;
        infc=color(179, 85, 119, 200) ;

        landBtn=new CircleButton(width/2, height/2-30, 270, higc, selc, "Landscape" ) ;
        portBtn=new CircleButton(width/2, height/2-490, 270, higc, selc, "Portrait" ) ;

        startBtn=new CircleButton(width/2, height/2-45, 260, higc, selc, "Start" ) ;
        //quitBtn=new RectButton(width-300,height/2-520,260,higc,selc, "  Quit" ) ;
        quitBtn=new RectButton(width-260, 150, 260, higc, selc, "  Quit" ) ;

        padBtn=new RectButton(5, height/2+140, 260, higc, selc, "Info" ) ;
        animBtn=new RectButton(width-300, height/2-360, 270, higc, selc, "Fast Show" ) ;
        fixBtn=new RectButton(5, height/2-520, 260, higc, selc, "Normal" ) ;
        // fixBtn=new RectButton(width/2-130, height/2-360, 260, higc, selc, "Normal" ) ;
        orientBtn=new CircleButton(width/2, height/2-290, 290, infc, higc, "Anthemist\n&\nPledger") ;

        updoAnimBtn=new RectButton(width-270, height/2+140, 270, higc, selc, "Pause" ) ;
        unanimBtn=new RectButton(width-300, height/2-80, 270, higc, selc, "Slow Show" ) ;
        backBtn=new RectButton(width-350, height-348, 290, infc, higc, "Use Back Key\n for menu" ) ;
        soundBtn=new RectButton(410, height/2+140, 270, higc, selc, "New Beat" ) ;
        pauseBtn=new RectButton(5, height-348, 270, higc, selc, "Recite" ) ;
        flashBtn=new RectButton(width-268, height-348, 267, higc, selc, "  Anthem" ) ;
        insBtn=new RectButton(5, 200, 230, higc, selc, "  \nReturn" ) ;
        spkBtn=new RectButton(300, 200, 230, higc, selc, "  \nSpeak" ) ;
    }

   public void draw()
    {

        //image(pscimg, 2,height/2,width,height/3) ;
        //loadaudio("cyber2.mp3") ;
        //  backBtn.display();
        if (locked==false)
            backBtn.update();
        else locked=false;


        if (clear) {
            clear();
            fill(c[j]);
            rect(x[j], y[j], w[j], h[j], 8);
            translate(x[j], y[j]);
        } else if (orientState) {
            clear() ;
            //    portBtn.display();
            //    landBtn.display();
            //    backBtn.display();
            //    if(locked==false) {
            //      portBtn.update();
            //      landBtn.update();
            //      backBtn.update();
            // }
            //  else  locked=false;
            textSize(45);
            tint(250);
            image(podimg, width /4, 30, width/2, height/3);
            tint(255, 167);
            image(eyeimg, 0, height/3, width, height/3+280);
            text("Name\nFrank Appiah, PhD\nURL\n https://www.appiahacademy.blogspot.com\n Facebook"
                    +"\nhttp://www.facebook.com/frankappiah \n\nBiography\nEphraim Kɔku Amu (13 September 1899 – 2 January 1995)\n[1] was a Ghanaian composer, musicologist and teacher.\nHistory :\nYɛn Ara Asaase Ni (English: This Is Our Own \nLand) is the unofficial national anthem of Ghana. \nIt was written and composed by Ephraim Amu \nin 1929[1] and is popularly sung in Twi. \nThe original is however in the Ewe language.\nhttps://en.m.wikipedia.org/wiki/Ephraim_Amu ", 5, height/3+110);
        } else if (flash) {
            clear();
            background(c[j]);
            flashRand=random(0, 255);
            stroke(flashRand);
            strokeWeight(5);
            fill(c[j]);
            rect(x[j], y[j], w[j], h[j], 8);
            translate(x[j], y[j]);
            translate(-x[j], - y[j]);
            msg=8;

            image(eyeimg, 2, height/4, width, height-188);
            backBtn.display();
            // loadaudio("cyber1.mp3") ;
            if (locked==false)
                backBtn.update();
            else
                locked=false;
        } else if (info) {
            clear();
            background(55);
            textSize(42) ;

            image(splash, width - width /4, 30, width/4, height/10);

            insBtn.display();
            spkBtn.display();
            if (locked==false) {
                insBtn.update();
                spkBtn.update();
            } else locked=false;

            // noFill() ;
            image(flagImage, 0, height/2-640, width, height/4+241);
            // delay(15);
            rect(0, 550, width, 180);
            fill(c[5]);
            text("  Recital:="+message[msg], 0, 630) ;
            textSize(55);
            text("Tap for \nnew anthem \nor pledge", width/2-88, 850);
            image(pad, 1, height/2+120, width, 680) ;
            textSize(40);
            text("\n    This application is used to recite the national \n     and the pledge to Ghanaian audience on training\n     the national pride moments. \n     App Developed By:Dr. Frank Appiah, SGTBIZ GH. \n    Donate: Vodafone Mobile Money via phone \n    number :+233204702873", 2, height/2+309);

            // text(menuStr, 40, 50);
        } else if (unanimate) {
            clear() ;
            unanim();
            translate(-x[j], -y[j]) ;
            backBtn.display();
            if (locked==false)
                backBtn.update();
            else locked=false;

            fill(c[j]);
            textSize(220);
            text("THE PLEDGE OF GHANA", 6, height/2+120) ;
            rect(width-230, height/2-440, 230, 200) ;
            fill(c[0]) ;
            rect(width-230, height/2-240, 230, 200) ;
            fill(c[1]) ;
            rect(width-430, height/2-440, 230, 200) ;
            fill(c[j] ) ;
            rect(width-430, height/2-240, 230, 200) ;

            fill(c[j] ) ;
            rect(width-630/2, height/5-440/2, 230, 200) ;
            fill(c[j]) ;
            rect(width-630/2, height/5-240/2, 230, 200) ;
            fill(c[3]) ;
            rect(width-830/2, height/5-440/2, 230, 200) ;
            fill(c[2] ) ;
            rect(width-830/2, height/5-240/2, 230, 200) ;

            fill(c[2]) ;
            rect(width-580, height-440, 230, 200) ;
            fill(c[j]) ;
            rect(width-580, height-240, 230, 200) ;
            fill(c[2]) ;
            rect(width-780, height-440, 230, 200) ;
            fill(c[j] ) ;
            rect(width-780, height-240, 230, 200) ;
            textSize(40);
            //loadaudio("cyber3.mp3") ;
            // if(==LANDSCAPE)
        } else if (animate) {
            clear() ;
            anim() ;
            translate(-x[j], -y[j]) ;

            backBtn.display();
            if (locked==false) {
                backBtn.update();
            } else {
                locked=false;
            }

            //loadaudio("cyber3.mp3") ;
            //translate(x[j], y[j]+40);
        } else if (animateUpDown) {
            clear();
            background(color(118, 79, 71));
            strokeWeight(5);
            brightness(155);
            image (bubble
                    , 2, 400, width, height/2) ;

            backBtn.display();
            // loadaudio("cyber4.mp3") ;
            if (locked==false )
                backBtn.update();
            else locked=false;
            //Down Animate
            if (UpDown==1) {
                if (j>0 && j<4) {
                    fill(c[j]);
                    if (j==2) {
                        fill(c[j]);
                        rect(x[j]+10, y[j]+180, w[j]-30, h[j], 8);
                    } else if (j==3) {
                        fill(c[j]);
                        rect(x[j]-65, y[j]+180, w[j]+48, h[j], 8);
                    } else {
                        fill(c[j]);
                        rect(x[j], y[j]+180, w[j], h[j], 8);
                    }
                    //rect(x[j], y[j]+180, w[j], h[j], 8);
                }
            } else {
                fill(c[1]);
                rect(x[1]-20, y[1]+180, w[1], h[1], 8);
                fill(c[2]);
                rect(x[2]-20, y[2]+180, w[2]-30, h[2], 8);
                fill(c[3]);
                rect(x[3]-65, y[3]+180, w[3]+48, h[3], 8);
            }

            //Up Animate
            if (UpDown==2) {
                if (j>0 && j<3) {
                    if (j==2) {
                        fill(c[j]);
                        rect(x[j]+10, y[j], w[j]-30, h[j], 8);
                    } else {
                        fill(c[j]);
                        rect(x[j], y[j], w[j], h[j], 8);
                    }
                    translate(x[j], y[j]);
                }
            } else {
                fill(c[0]);
                rect(x[0], y[0], w[0], h[0], 8);
                fill(c[4]);
                rect(x[4], y[4], w[4], h[4], 8);
                if (j>0 && j<3) {
                    if (j==2) {
                        fill(c[j]);
                        rect(x[j]+10, y[j], w[j]-30, h[j], 8);
                    } else {
                        fill(c[j]);
                        rect(x[j], y[j], w[j], h[j], 8);
                    }
                    translate(x[j], y[j]);
                }
            }
            UpDown++;
            if (UpDown>2) UpDown=0;

                //translate(x[j], y[j]+40);
            else {
                stroke(0);
                strokeWeight(2);
            }
            translate(-x[j], -y[j]) ;
        }
        // if(!animateUpDown&&!menu)
        // translate(-x[j], -y[j]) ;
        else if (start) {
            clear() ;


            fill(c[j]) ;
            textSize(45);
            image(pad, 0, height-209, width, 250) ;
            text("\n    " +message[m], 2, height-94);
            image(pscimg, 1, height/2-633, width/2, height/4+241);
            backBtn.display();
            pauseBtn.display();
            if (locked==false ) {
                backBtn.update();
                pauseBtn.update();
            } else locked=false;
            //displayMenu(!start);
            image(pscimg, 2, height/2, width, height/3) ;
            image (bubble
                    , width - width/2, 8, width/2, height/4) ;
            textSize(110) ;
            fill(c[j]);
            text("ANTHEM RECITAL", 6, height/2-520) ;
            rect(width-230, height/2-440, 230, 200) ;
            rect(width-230, height/2-240, 230, 200) ;
            fill(c[0] ) ;
            rect(width-430, height/2-440, 230, 200) ;
            rect(width-430, height/2-240, 230, 200) ;
            // if(==LANDSCAPE)
        } else if (menu) {
            clear() ;
            textSize(40) ;
            tint(c[j], 255) ;
            //brightness(c[j] ) ;
            image(splash, 0, 0, width, height);
            //background(color(#135572, 33));
            strokeWeight(5);
            fill(c[4], 212);
            rect(x[0]+50, y[0]+180, w[0], h[0], 8);
            fill(c[3], 122);
            rect(x[1]+70, y[1]+180, w[1], h[1], 8);
            fill(c[2], 5);
            rect(x[2]+70, y[2]+180, w[2]-30, h[2], 8);
            fill(c[1], 7);
            rect(x[3]+50, y[3]+180, w[3], h[3], 8);
            fill(c[0], 33);
            rect(x[4]+50, y[4]+180, w[4], h[4], 8);
            fill(c[j], 12);
            rect(x[j], y[j], w[j], h[j], 8);
            translate(x[j], y[j]);
            translate(-x[j], -y[j]) ;
            displayMenu(menu);

            text("Press Anthem to change to Pledge or vice-versa", 23, height-30) ;
            //image(pscimg, 2,height/2,width,height/3) ;
            if (locked==false) {
                //      startBtn.update();
                //      animBtn.update();
                //      unanimBtn.update();
                //      fixBtn.update();
                updoAnimBtn.update();
                padBtn.update();
                quitBtn.update();
                soundBtn.update();
                flashBtn.update();
                pauseBtn.update();
                orientBtn.update();
                if (flag> 21) flag=0;
                tint(255, 128);
                flagImage=loadImage(flags[flag]) ;
                image(flagImage, 0, height/4+72, 400, 450);
                flag++;
            } else locked=false;
            textSize(100) ;
            text("ANTHEM AND PLEDGE", 40, 140);
            textSize(40);
            text("National Anthem and The Pledge. ", width/2-60, height/2-530);

            //drawShape();
        }
        //image(comov, width/4, height/2, width/5,height/5) ;
        m++;
        b++;
        s++;
        eye++;

        j++;
        if (b>63) b=1;
        if (j>4) j=0;
        if (m>message.length)m=0;
        if (s>58)s=1;
        if (eye>269) eye=175;
    }

    void drawShape() {

        textSize(89) ;
        fill(c[j]);
        text("GHANA ANTHEM\n AND \nTHE PLEDGE ", 6, height/2+349) ;
        rect(width-230, height/2-440, 230, 200) ;
        rect(width-230, height/2-240, 230, 200) ;
        fill(c[2] ) ;
        rect(width-430, height/2-440, 230, 200) ;
        rect(width-430, height/2-240, 230, 200) ;
        translate(width-200, height/2-260);
        rotateX(frameCount * 0.04f);
        rotateY(frameCount * 0.04f);
        fill(c[j]) ;
        //shape(cube);
        textSize(48);
        text("SGTBIZ APP", width/3, height/2) ;
        rect(width-230, height/2-90, 70, 80) ;
        rect(width-80, height/2-70, 80, 80) ;
        rect(width-123, height/2-100, 30, 80) ;
        // if (wiggling) {
        //    PVector pos = null;
        //    for (int i = 0; i < cube.getChildCount(); i++) {
        //      PShape face = cube.getChild(i);
        //      for (int j = 0; j < face.getVertexCount(); j++) {
        //        pos = face.getVertex(j, pos);
        //        pos.x += random(-noiseMag/2, +noiseMag/2);
        //        pos.y += random(-noiseMag/2, +noiseMag/2);
        //        pos.z += random(-noiseMag/2, +noiseMag/2);
        //        face.setVertex(j, pos.x, pos.y, pos.z);
        //      }
        //    }
        //   }
    }

    void unanim() {
        clear();
        background(color(118,79,67));
        strokeWeight(5);
        fill(c[4]);
        rect(x[0], y[0]+180, w[0], h[0], 8);
        fill(c[3]);
        rect(x[1], y[1]+180, w[1], h[1], 8);
        fill(c[2]);
        rect(x[2], y[2]+180, w[2], h[2], 8);
        fill(c[1]);
        rect(x[3], y[3]+180, w[3], h[3], 8);
        fill(c[0]);
        rect(x[4], y[4]+180, w[4], h[4], 8);
        fill(c[j]);
        rect(x[j], y[j], w[j], h[j], 8);
        translate(x[j], y[j]);
    }

    void anim() {
        clear();
        background(color(118, 79, 119));
        strokeWeight(5);
        fill(c[0]);
        rect(x[0], y[0]+180, w[0], h[0], 8);
        if (j<4) {
            fill(c[j]);
            if (j==2 && w[j]<=-50) rect(x[j]+30, y[j]+180, w[j]-30, h[j], 8);
            else if (j==3) rect(x[j]-48, y[j]+180, w[j]+48, h[j], 8);
            else rect(x[j], y[j]+180, w[j], h[j], 8);
        }
        fill(c[4]);
        rect(x[4], y[4]+180, w[4], h[4], 8);

        fill(c[j]);
        rect(x[j], y[j], w[j], h[j], 8);
        translate(x[j], y[j]);
    }

    void fastanim() {
    }

    void closeApp() {
        mp.release();
        mp.stop();
    }

    void displayMenu(boolean show) {

        //    startBtn.display(show);
        orientBtn.display(show) ;
        padBtn.display(show);
        //    animBtn.display(show);
        //    unanimBtn.display(show);
        updoAnimBtn.display(show);
        // fixBtn.display(show);
        quitBtn.display(show);
        soundBtn.display(show );
        flashBtn.display(show);
        pauseBtn.display(show);
    }

   public void backPressed() {
        start=false;
        flash=false;
        clear=false;
        unanimate=false;
        animate=false;
        fixed=false;
        menu=true;
        animateUpDown=false;
        info=false;
        if (mp.isPlaying()) {
            mp.pause();
            pause=false;
        }
    }

    void update() {
        if (mousePressed) {
            if (pauseBtn.pressed()) {
                //  HashMap<String> voices =new HashMap<String>() ;
                // voices.put();
                if (pledge) {//pledge
                    t1.speak(message[msg], TextToSpeech.QUEUE_FLUSH, null);
                } else
                    t1.speak(message[msg], TextToSpeech.QUEUE_FLUSH, null);
                displayMenu(false) ;
                msg++;
            } else if (quitBtn.pressed()) {
                closeApp();
            } else if (flashBtn.pressed())
            {
                start=false;
                flash=false;
                clear=false;
                unanimate=false;
                animate=false;
                fixed=false;
                if (pledge) {
                    pledge=false;
                    msg=0;
                    flashBtn=new RectButton(width-268, height-348, 267, higc, selc, "  Anthem" ) ;
                } else {
                    pledge=true;
                    msg=10;
                    flashBtn=new RectButton(width-268, height-348, 267, higc, selc, "  Pledge" ) ;
                }
                menu=true;
                animateUpDown=false;
                info=false;
                frameRate(2);
            } else if (orientBtn.pressed()) {
                start=false;
                flash=false;
                clear=false;
                unanimate=false;
                animate=false;
                fixed=false;
                menu=false;
                info=false;
                animateUpDown=false;
                orientState=true;
            } else if (updoAnimBtn.pressed())
            {
                //  start=false;
                // animateUpDown=true;
                //   flash=false; info=false;
                //   clear=false;
                //  unanimate=false;
                //  animate=false;
                //  fixed=false;
                menu=true;
                if (pause) {
                    pause=false;
                    mp.pause();
                } else {
                    pause=true;
                    mp.start();
                }
                frameRate(4);
            }
            // else if (fixBtn.pressed())
            //    {start=false;
            //      fixed=true;
            //      unanimate=false;info=false;
            //      animate=false;
            //      flash=false;
            //      clear=false;
            //      menu=false;
            //      animateUpDown=false;
            //    }
            else if (soundBtn.pressed())
            {
                start=false;
                try {
                    //
                    mp.pause();
                    mp=new MediaPlayer() ;
                    afd = context.getAssets().openFd(sb[be]);//which is in the data folder
                    //println("Successfully loaded audio file");
                    mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                    mp.setLooping(true);
                    mp.setVolume(0.9f, 0.9f);
                    mp.prepare();
                    mp.start() ;
                    frameRate(2);
                    be++;
                    if (be>3) {
                        be=0;
                    }
                }
                catch(IOException  x) {
                    x.printStackTrace();
                }
            } else if (unanimBtn.pressed())
            {
                start=false;
                unanimate=true;
                animate=false;
                flash=false;
                clear=false;
                info=false;
                fixed=false;
                menu=false;
                animateUpDown=false;
                frameRate(2);
            } else if (animBtn.pressed())
            {
                start=false;
                animate=true;
                info=false;
                unanimate=false;
                flash=false;
                clear=false;
                fixed=false;
                menu=false;
                animateUpDown=false;
                frameRate(40) ;
            } else if (startBtn.pressed()) {
                start=true;
                menu=false;
                info=false;
                animate=false;
                unanimate=false;
                flash=false;
                clear=false;
                fixed=false;
                animateUpDown=false;
                displayMenu(false) ;
            } else if (backBtn.pressed()) {
                menu=true;
                clear=false;
                animate=false;
                unanimate=false;
                flash=false;
                info=false;
                fixed=false;
                animateUpDown=false;
                start=false;
                displayMenu(true) ;
            } else if (insBtn.pressed()) {
                menu=true;
                clear=false;
                animate=false;
                unanimate=false;
                info=false;
                flash=false;
                fixed=false;
                animateUpDown=false;
                start=false;
                displayMenu(true) ;
            } else if (spkBtn.pressed()) {
                // Toast.makeText(context, message[msg] ,Toast.LENGTH_SHORT).show();
                start=false;
                //if(menu)
                animate=false;
                menu=false;
                unanimate=false;
                info=true;
                flash=false;
                clear=false;
                fixed=false;
                animateUpDown=false;
                displayMenu(start&menu);
                t1.speak(message[msg], TextToSpeech.QUEUE_FLUSH, null);
            } else if (padBtn.pressed())
            {
                menu=false ;
                msg++;
                if (msg>20) msg=0;
                animate=false;
                unanimate=false;
                info=true;
                flash=false;
                clear=false;
                fixed=false;
                animateUpDown=false;
                start=false;
                displayMenu(false) ;
            } else flash=false;
        }
    }

    public void mousePressed()
    {

        /// if(!showKB) {openKeyboard();showKB=true;}
        //else {closeKeyboard();showKB=false;}
        if (locked==false && menu==true) {
            //  padBtn.update();
            //  orientBtn.update();
            //  startBtn.update();
            //  animBtn.update();
            //  unanimBtn.update();
            //  updoAnimBtn.update();
            //  fixBtn.update();
            quitBtn.update() ;
            pauseBtn.update();
            soundBtn.update();
            flashBtn.update();
            backBtn.update();
            //insBtn.update();
            // spkBtn.update();
        } else if (locked==false && info==true) {

            println("info") ;
            insBtn.update();
            spkBtn.update();
        } else if (locked==false && start==true) {

            println("start") ;
            backBtn.update();
            pauseBtn.update();
        } else {
            println("Default") ;
            locked=false;
            backBtn.update();
            //   insBtn.update();
        }

        update() ;
    }


    class Button {
        int x, y;
        int size=120, textSize=40;
        String text;
        int baseColor, highlightColor;
        int currentColor;
        boolean locked, over = false;
        boolean pressed = false;
        boolean show=false;

        void update() {
            if (over()) {
                currentColor = highlightColor;
            } else {
                currentColor = baseColor;
            }
        }

        void setTextSize(int textS) {
            textSize=textS;
        }

        boolean pressed() {
            if (over) {
                locked = true;
                return true;
            } else {
                locked = false;
                return false;
            }
        }

        boolean over() {
            return true;
        }

        boolean overRect(int x, int y, int width, int height) {
            if (mouseX >= x && mouseX <= x + width
                    && mouseY >= y && mouseY <= y + height) {

                return true;
            } else {
                return false;
            }
        }

        boolean overCircle(int x, int y, int diameter) {
            float disX = x - mouseX;
            float disY = y - mouseY;
            if (sqrt(sq(disX) + sq(disY)) < diameter / 2 ) {
                return true;
            } else {
                return false;
            }
        }
    }

    class CircleButton extends Button {

        CircleButton(int ix, int iy, int isize, int icolor, int ihighlight, String itext) {
            x = ix;
            y = iy;
            text=itext;
            size = isize;
            baseColor = icolor;
            highlightColor = ihighlight;
            currentColor = baseColor;
        }

        boolean over() {
            if (overCircle(x, y, size)) {
                over = true;
                if (show) {
                    fill(18, 149,213, 250);
                    ellipse(x, y, size+20, size+20);
                }
                return true;
            } else {
                over = false;
                return false;
            }
        }

        void display() {
            stroke(255);
            fill(currentColor);
            ellipse(x, y, size, size);
            fill(color(255, 250, 255)) ;
            textSize(textSize) ;
            if (x>0 || y>0)
                text(text, x+size/2-3*textSize, y+size/2-3*textSize) ;
            else
                text(text, textSize, y+size/2-3*textSize) ;
        }

        void display(boolean draw ) {
            show=draw ;
            if (draw)
            {
                stroke(255);
                fill(currentColor) ;
                ellipse(x, y, size, size);
                fill(color(255, 250, 233));
                if (x>0 || y>0)
                    text(text, x+size/2-3*textSize, y+size/2-3*textSize) ;
                else
                    text(text, textSize, y+size/2-3*textSize);
            } else clear() ;
        }
    }

    class RectButton extends Button {
        RectButton(int ix, int iy, int isize, int icolor, int ihighlight, String itext) {
            x = ix;
            y = iy;
            size = isize;
            text=itext;
            baseColor = icolor;
            highlightColor = ihighlight;
            currentColor = baseColor;
        }

        boolean over() {
            if (overRect(x, y, size, size)) {
                over = true;
                if (show) {
                    fill(19, 235, 149, 250);
                    rect(x-30, y-35, size+50, size/2+66);
                }
                return true;
            } else {
                over = false;
                return false;
            }
        }

        void display() {
            stroke(255);
            fill(currentColor) ;
            rect(x, y, size, size/2, 45);
            fill(color(255, 250, 233));
            if (x>0 || y>0)
                text(text, x+size/2-3*textSize, y+size/2-2*textSize) ;
            else
                text(text, textSize, y+size/2-2*textSize);
        }



        void display(boolean draw) {
            show=false;
            if (draw) {
                stroke(255);
                fill(currentColor) ;
                rect(x, y, size, size/2, 45);
                fill(color(255, 250, 233));
                if (x>0 || y>0)
                    text(text, x+size/2-3*textSize, y+size/2-2*textSize) ;
                else
                    text(text, textSize, y+size/2-2*textSize);
            } else clear() ;
        }
    }
}

